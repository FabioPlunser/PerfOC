// data_structures.h
#ifndef DATA_STRUCTURES_H
#define DATA_STRUCTURES_H

#include <stddef.h>

// Array structure
typedef struct {
    void* data;
    size_t size;
    size_t capacity;
    size_t element_size;
} Array;

// Linked list node
typedef struct Node {
    void* data;
    struct Node* next;
} Node;

// Linked list structure
typedef struct {
    Node* head;
    size_t size;
    size_t element_size;
} LinkedList;

// Array functions
Array* array_create(size_t initial_capacity, size_t element_size);
void array_destroy(Array* arr);
void array_insert(Array* arr, size_t index, const void* element);
void array_delete(Array* arr, size_t index);
void* array_get(Array* arr, size_t index);
void array_set(Array* arr, size_t index, const void* element);

// Linked list functions
LinkedList* linked_list_create(size_t element_size);
void linked_list_destroy(LinkedList* list);
void linked_list_insert(LinkedList* list, size_t index, const void* element);
void linked_list_delete(LinkedList* list, size_t index);
void* linked_list_get(LinkedList* list, size_t index);
void linked_list_set(LinkedList* list, size_t index, const void* element);

#endif