#ifndef TIMING_H
#define TIMING_H

#include <stdint.h>

double get_time();
uint64_t get_cycles();

#endif
