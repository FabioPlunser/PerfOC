#include "data_structures.h"
#include <stdlib.h>
#include <string.h>

// Array functions
Array* array_create(size_t initial_capacity, size_t element_size) {
  Array* arr = malloc(sizeof(Array));
  arr->data = malloc(initial_capacity * element_size);
  arr->size = initial_capacity;
  arr->capacity = initial_capacity;
  arr->element_size = element_size;
  return arr;
}

